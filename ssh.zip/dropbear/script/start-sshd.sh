#!/bin/sh



DIR=$(dirname $(dirname $(realpath $0)/))
ARGS="-r $DIR/etc/dropbear_dss_host_key \
-r $DIR/etc/dropbear_ecdsa_host_key \
-r $DIR/etc/dropbear_rsa_host_key \
-r $DIR/etc/dropbear_ed25519_host_key \
-p 0.0.0.0:22"
NODAEMON=0

if [ "x${1}x" != "xx" -a "x${1}x" != "x0x" ]; then
    NODAEMON=1
fi

for key_type in dss ecdsa rsa ed25519; do
    host_key_file=$DIR/etc/dropbear_${key_type}_host_key   
    if [ ! -e $host_key_file ]; then
        $DIR/bin/dropbearkey -t $key_type -f $host_key_file
    fi
done

if [ $NODAEMON = 0 ]; then
    LD_PRELOAD=$DIR/lib/libcrypt.so $DIR/sbin/dropbear $ARGS
else
    LD_PRELOAD=$DIR/lib/libcrypt.so $DIR/sbin/dropbear $ARGS -E -F
fi
