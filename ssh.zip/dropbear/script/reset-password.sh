#!/bin/sh

sed 's|^root:[^:]*:|root:$1$tDJARXeQ$DKsqueuqauK/xPi8t/4Pk0:|' /etc/shadow >/tmp/shadow
mount -o bind -t none /tmp/shadow /etc/shadow
